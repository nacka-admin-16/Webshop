﻿namespace BestOfBrands.tenta.PizzaExercise
{
    public class Ingrediens
    {
        public string Namn { get; set; }
    }
}