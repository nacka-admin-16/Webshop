﻿using System.Collections.Generic;

namespace BestOfBrands.tenta.PizzaExercise
{
    public class Order
    {
        public List<Pizza> Pizzas { get; set; }  = new List<Pizza>();
    }
}